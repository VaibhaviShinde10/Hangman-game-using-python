import tkinter as tk
from tkinter import messagebox
import random

# --- Word list with hints ---
WORDS = {
    "python": "A popular programming language 🐍",
    "apple": "A fruit that keeps the doctor away 🍎",
    "guitar": "A musical instrument with strings 🎸",
    "elephant": "The largest land animal 🐘",
    "rainbow": "Appears after rain 🌈",
    "computer": "A machine that processes data 💻",
    "diamond": "A precious stone 💎",
    "pencil": "Used for writing ✏️",
    "frog":"🐸"
}

# --- Hangman ASCII drawings ---
HANGMAN_PICS = [
    """
       +---+
           |
           |
           |
          ===
    """,
    """
       +---+
       O   |
           |
           |
          ===
    """,
    """
       +---+
       O   |
       |   |
           |
          ===
    """,
    """
       +---+
       O   |
      /|   |
           |
          ===
    """,
    """
       +---+
       O   |
      /|\\  |
           |
          ===
    """,
    """
       +---+
       O   |
      /|\\  |
      /    |
          ===
    """,
    """
       +---+
       O   |
      /|\\  |
      / \\  |
          ===
    """,
]


class HangmanGame:
    def __init__(self, root):
        self.root = root
        self.root.title("🎯 Hangman Game (GUI)")
        self.root.geometry("600x550")
        self.root.config(bg="#FFF8DC")

        # Pick a random word and hint
        self.word, self.hint = random.choice(list(WORDS.items()))
        self.guessed = ["_"] * len(self.word)
        self.tries = 0
        self.max_tries = len(HANGMAN_PICS) - 1

        # Hint Label
        self.hint_label = tk.Label(
            root, text=f"Hint: {self.hint}", font=("Comic Sans MS", 14), bg="#FFF8DC"
        )
        self.hint_label.pack(pady=10)

        # ASCII Hangman display
        self.hangman_label = tk.Label(
            root, text=HANGMAN_PICS[self.tries], font=("Courier", 14), bg="#FFF8DC", justify="left"
        )
        self.hangman_label.pack(pady=5)

        # Word display (underscores)
        self.word_label = tk.Label(
            root,
            text=" ".join(self.guessed),
            font=("Courier", 24, "bold"),
            bg="#FFF8DC",
        )
        self.word_label.pack(pady=20)

        # Input box
        self.entry = tk.Entry(root, font=("Arial", 16), justify="center")
        self.entry.pack()

        # Guess button
        self.guess_button = tk.Button(
            root,
            text="Guess",
            command=self.make_guess,
            font=("Arial", 14),
            bg="#90EE90",
            activebackground="#77DD77",
        )
        self.guess_button.pack(pady=10)

        # Remaining tries label
        self.tries_label = tk.Label(
            root,
            text=f"Tries left: {self.max_tries - self.tries}",
            font=("Arial", 12, "bold"),
            bg="#FFF8DC",
        )
        self.tries_label.pack(pady=5)

    def make_guess(self):
        guess = self.entry.get().lower()
        self.entry.delete(0, tk.END)

        if not guess.isalpha() or len(guess) != 1:
            messagebox.showinfo("Invalid Input", "Please enter a single letter.")
            return

        if guess in self.guessed:
            messagebox.showinfo("Repeat", "You already guessed that letter!")
            return

        if guess in self.word:
            for i, letter in enumerate(self.word):
                if letter == guess:
                    self.guessed[i] = guess
        else:
            self.tries += 1

        self.hangman_label.config(text=HANGMAN_PICS[self.tries])
        self.word_label.config(text=" ".join(self.guessed))
        self.tries_label.config(text=f"Tries left: {self.max_tries - self.tries}")

        # Check game over conditions
        if "_" not in self.guessed:
            messagebox.showinfo("🎉 You Win!", f"Correct! The word was '{self.word}'.")
            self.root.destroy()
        elif self.tries == self.max_tries:
            messagebox.showerror("💀 Game Over", f"You lost! The word was '{self.word}'.")
            self.root.destroy()


# --- Run Game ---
if __name__ == "__main__":
    root = tk.Tk()
    game = HangmanGame(root)
    root.mainloop()
